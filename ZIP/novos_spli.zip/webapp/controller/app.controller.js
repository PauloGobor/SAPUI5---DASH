sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("novo_spfli.novos_spli.controller.app", {
		onInit: function () {

		}
	});
});