sap.ui.define([
	"novo_spfli/novos_spli/test/unit/controller/app.controller"
], function () {
	"use strict";
});