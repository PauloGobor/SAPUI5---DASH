sap.ui.define([
	"ZSflight_dash/ZSflight_dash/test/unit/controller/App.controller"
], function () {
	"use strict";
});