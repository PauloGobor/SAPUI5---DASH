sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("ZSflight_dash.ZSflight_dash.controller.App", {
		onInit: function () {

		}
	});
});