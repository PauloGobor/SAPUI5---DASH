sap.ui.define([
	"Docs/ZZZDocs/test/unit/controller/App.controller"
], function () {
	"use strict";
});