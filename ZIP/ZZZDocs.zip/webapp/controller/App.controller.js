sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("Docs.ZZZDocs.controller.App", {
		onInit: function () {

		}
	});
});