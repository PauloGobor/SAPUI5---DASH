sap.ui.define([
	"DashVoos/ProjetVoosDash/test/unit/controller/App.controller"
], function () {
	"use strict";
});