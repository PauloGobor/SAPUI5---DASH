sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/Filter"
], function (Controller, MessageToast, Filter) {
	"use strict";

	return Controller.extend("ZCADPESSOA.ZCADPESSOA.controller.App", {
		onInit: function () {

		},
		
	

	});
});