sap.ui.define([
	"ZCADPESSOA/ZCADPESSOA/test/unit/controller/App.controller"
], function () {
	"use strict";
});